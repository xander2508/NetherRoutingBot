import os
import random
import discord
from discord.ext import commands

TOKEN = "OTE2MDI5MTk3NDY0NTI2OTA5.YakMqw.iwXwIwGqoHevDhLpVpgSWOuAM74"
GUILD="The Mapping Server"

client = discord.Client()
bot = commands.Bot(command_prefix='!')

@bot.event
async def on_ready():
    print(f'{bot.user.name} has connected to Discord!')
    
@bot.command(name='99')
async def nine_nine(ctx):
    brooklyn_99_quotes = [
        'I\'m the human form of the 💯 emoji.',
        'Bingpot!',
        (
            'Cool. Cool cool cool cool cool cool cool, '
            'no doubt no doubt no doubt no doubt.'
        ),
    ]

    response = random.choice(brooklyn_99_quotes)
    await ctx.send(response)
bot.run(TOKEN)
